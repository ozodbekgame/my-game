ПОБЕГ ИЗ БЭКРУМС — проект для APK

Быстрый способ (Windows/Mac/Linux):
1. Установи Node.js, JDK 17 и Android Studio (один раз).
2. В этой папке запусти:  ./build.sh   (на Windows через Git Bash)
3. APK: android/app/build/outputs/apk/debug/app-debug.apk
   Скинь на телефон и установи (разреши установку из неизвестных источников).

Иконка берётся из resources/ автоматически.
Для публикации в Google Play нужна подписанная release-сборка (Build > Generate Signed Bundle в Android Studio).

БЕЗ КОМПЬЮТЕРА / БЕЗ УСТАНОВКИ ПРОГРАММ (через GitHub):
1. Создай бесплатный аккаунт на github.com и новый репозиторий (ветка main).
2. Загрузи в него ВСЕ файлы из этой папки (Add file > Upload files), включая папку .github.
3. Открой вкладку Actions > Build APK > Run workflow.
4. Через ~5 минут внутри запуска появится файл backrooms-apk. Скачай, распакуй, установи app-debug.apk.
