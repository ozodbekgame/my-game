#!/bin/bash
# Нужны: Node.js 18+, JDK 17, Android Studio (или Android SDK). Интернет нужен один раз.
set -e
curl -L -o www/three.min.js https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
npm install
npx cap add android
npx capacitor-assets generate --android
# горизонтальный экран и полноэкранный режим
M=android/app/src/main/AndroidManifest.xml
sed -i 's/<activity /<activity android:screenOrientation="sensorLandscape" /' "$M"
npx cap sync android
cd android && ./gradlew assembleDebug
echo "Готово: android/app/build/outputs/apk/debug/app-debug.apk"
